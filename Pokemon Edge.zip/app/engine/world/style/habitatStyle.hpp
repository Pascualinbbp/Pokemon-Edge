#pragma once
#include <cstdint>
#include <string>
#include <DirectXMath.h>

// Aspecto de cada hábitat (único sitio donde se define): color del suelo. Un hábitat sin entrada recibe un color derivado
// de su nombre, así que añadirlo a la base de datos basta para verlo.
namespace HabitatStyle {
    inline DirectX::XMFLOAT3 color(const std::string& name) {
        if (name == "Pradera") return { 0.30f, 0.72f, 0.26f };
        if (name == "Bosque de robles") return { 0.16f, 0.52f, 0.18f };
        if (name == "Bosque de pinos") return { 0.08f, 0.36f, 0.24f };
        if (name == "Bosque mixto") return { 0.14f, 0.45f, 0.20f };
        if (name == "Bosque de cerezos") return { 0.72f, 0.62f, 0.52f };   // hierba cubierta de pétalos rosados
        if (name == "Jungla") return { 0.10f, 0.42f, 0.14f };
        if (name == "Sabana") return { 0.76f, 0.66f, 0.30f };
        if (name == "Campo de flores") return { 0.50f, 0.80f, 0.36f };
        if (name == "Cueva de nube") return { 0.88f, 0.92f, 1.0f };
        if (name == "Montaña") return { 0.48f, 0.46f, 0.44f };
        if (name == "Playa") return { 0.90f, 0.84f, 0.58f };
        if (name == "Río") return { 0.25f, 0.55f, 0.85f };
        if (name == "Lago") return { 0.15f, 0.40f, 0.72f };
        if (name == "Orilla de río") return { 0.42f, 0.62f, 0.34f };
        if (name == "Orilla de lago") return { 0.46f, 0.60f, 0.38f };
        if (name == "Orilla del mar") return { 0.30f, 0.74f, 0.84f };
        if (name == "Mar") return { 0.14f, 0.44f, 0.76f };
        if (name == "Mar profundo") return { 0.05f, 0.18f, 0.46f };
        if (name == "Pantano") return { 0.30f, 0.38f, 0.22f };
        if (name == "Desierto") return { 0.82f, 0.66f, 0.36f };
        if (name == "Tundra") return { 0.86f, 0.92f, 0.96f };
        if (name == "Cueva") return { 0.32f, 0.30f, 0.30f };
        if (name == "Mina") return { 0.38f, 0.33f, 0.28f };
        if (name == "Isla del cielo") return { 0.96f, 0.97f, 1.0f };      // suelo de nube
        if (name == "Tierra del cielo") return { 0.52f, 0.78f, 0.38f };   // islotes de tierra
        if (name == "Mar de nubes") return { 0.78f, 0.86f, 1.0f };
        if (name == "Volcán") return { 0.20f, 0.17f, 0.17f };              // roca negra
        if (name == "Río de lava") return { 0.62f, 0.14f, 0.04f };
        if (name == "Roca volcánica") return { 0.14f, 0.13f, 0.14f };   // basalto frío
        if (name == "Aguas termales") return { 0.72f, 0.70f, 0.60f };
        if (name == "Géiser") return { 0.78f, 0.74f, 0.62f };               // costra de minerales
        if (name == "Arrecife de coral") return { 0.88f, 0.60f, 0.58f };
        if (name == "Campo de algas") return { 0.22f, 0.50f, 0.34f };
        if (name == "Volcán submarino") return { 0.18f, 0.20f, 0.26f };
        if (name == "Fumarolas") return { 0.55f, 0.42f, 0.28f };
        if (name == "Glaciar") return { 0.66f, 0.84f, 0.96f };
        if (name == "Gruta volcánica") return { 0.20f, 0.14f, 0.14f };
        if (name == "Gruta de hielo") return { 0.62f, 0.82f, 0.95f };
        uint32_t hash = 2166136261u;
        for (const char c : name) hash = (hash ^ static_cast<unsigned char>(c)) * 16777619u;
        return { 0.3f + 0.5f * static_cast<float>(hash & 0xFF) / 255.0f, 0.3f + 0.5f * static_cast<float>((hash >> 8) & 0xFF) / 255.0f,
                 0.3f + 0.5f * static_cast<float>((hash >> 16) & 0xFF) / 255.0f };
    }
}
