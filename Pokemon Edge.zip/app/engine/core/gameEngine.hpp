#pragma once
#include "../../utils/core/crashUtil.hpp"
#include <cstdio>
#include <utility>
#include "../../utils/core/loggerUtil.hpp"
#include <vector>
#include "../audio/audioEngine.hpp"
#include "../audio/wav.hpp"
#include "../../utils/core/resourceUtil.hpp"
#include "../world/scene.hpp"
#include "../render/renderer3D.hpp"
#include "../../models/gameData.hpp"
#include "../../models/saveData.hpp"
#include "gameStatus.hpp"
#include "input.hpp"
#include "../audio/mp3Source.hpp"

class GameEngine {
    public:
    // Fondo propio del juego (independiente del fondo de la GUI).
    static constexpr float CLEAR_COLOR[4] = { 0.09f, 0.10f, 0.13f, 1.0f };

    void init(ID3D11Device* device) {
        m_renderer.init(device);
        m_audio.init([](const std::string& path) -> Audio::ClipPtr { // los efectos están incrustados en el exe (assets/audio/...)
            const ResourceUtil::Blob blob = ResourceUtil::loadAsset(path);
            return blob ? Audio::Wav::parse(blob.data, blob.size) : nullptr;
        }, [](const std::string& path) -> Audio::RadioPtr { // las emisoras: MP3 (se lee directamente del exe, sin copiarlo) o, si no, WAV
            const ResourceUtil::Blob mp3 = ResourceUtil::loadAsset(path + ".mp3");
            if (mp3) return Audio::Mp3Source::open(mp3.data, mp3.size);
            const ResourceUtil::Blob wav = ResourceUtil::loadAsset(path + ".wav");
            const Audio::ClipPtr clip = wav ? Audio::Wav::parse(wav.data, wav.size) : nullptr;
            return clip ? std::make_shared<Audio::ClipSource>(clip) : nullptr;
        });
    }

    // Al salir de la partida deja de sonar la radio.
    void silence() { m_audio.silence(); }

    // Datos de juego de la base de datos (pokéballs, objetos, cofres...): con ellos se crea cada partida.
    // El mundo no se genera aquí sino al empezar o cargar una partida (buildNew / buildSaved).
    void setData(GameData data) {
        m_data = std::move(data);
    }

    // El mundo se construye sin tocar la GPU, así que puede hacerse en otro hilo mientras la pantalla de carga sigue dibujándose.
    Scene buildNew() const { return Scene(m_data); }

    Scene buildSaved(const SaveData& save) const {
        Scene scene = save.worldSeed != 0 ? Scene(m_data, save.worldSeed) : Scene(m_data);
        float x = save.playerPosition[0], z = save.playerPosition[2];
        if (!scene.habitats.playable(x, z)) x = z = 0.0f; // partidas de antes del mundo nuevo: el inicio
        scene.player.body.position = { x, (std::max)(save.playerPosition[1], scene.world.surfaceHeight(x, z)) + 0.5f, z };
        scene.dayCycle.setTime(save.worldTime);
        scene.exploration.restore(save.explored);
        scene.inventory.restore(save.items, save.selectedBall, save.money);
        scene.storage.restore(save.team, save.pc, save.autoReleaseRank, save.activeIndex);
        scene.storage.restoreDex(save.dexSeen, save.dexCaught);
        scene.storage.dexProgress.restore(save.dexProgress);
        scene.progress.restore(save.playerLevel, save.playerXp, save.badgeMask);
        return scene;
    }

    void adopt(Scene&& scene) { m_scene = std::move(scene); }

    SaveData captureSave() const {
        const DirectX::XMFLOAT3& p = m_scene.player.body.position;
        SaveData save;
        save.playerPosition = { p.x, p.y, p.z };
        save.worldTime = m_scene.dayCycle.time();
        save.worldSeed = m_scene.habitats.seed();
        save.explored = m_scene.exploration.store();
        m_scene.inventory.store(save.items, save.selectedBall, save.money);
        m_scene.storage.store(save.team, save.pc);
        m_scene.storage.storeDex(save.dexSeen, save.dexCaught);
        m_scene.storage.dexProgress.store(save.dexProgress);
        save.autoReleaseRank = m_scene.storage.autoRankIndex();
        save.activeIndex = m_scene.storage.activeIndex();
        save.playerLevel = m_scene.progress.level();
        save.playerXp = m_scene.progress.xp();
        save.badges = m_scene.progress.badges();
        save.badgeMask = m_scene.progress.badgeMask();
        save.summary = { {}, save.playerLevel, save.badges, m_scene.inventory.money(), m_scene.storage.dexCount(PokemonStorage::DEX_CAUGHT) };
        for (const OwnedPokemon& owned : m_scene.storage.team()) save.summary.team.push_back({ owned.speciesId, owned.level, owned.shiny });
        return save;
    }

    // Devuelve true si se pide pausar (ESC fuera del modo lanzamiento).
    bool update(float dt, const InputState& input) {
        CRASH_SCOPE();
        const DirectX::XMFLOAT3& at = m_scene.player.body.position;
        CrashUtil::detail("x=%.1f y=%.1f z=%.1f", at.x, at.y, at.z);
        CrashUtil::stage("juego: actualizar");
        m_scene.dayCycle.update(dt); // el tiempo del mundo corre siempre mientras se juega, haga lo que haga el jugador
        const bool pause = m_scene.update(dt, input);
        const DirectX::XMFLOAT3& head = m_scene.player.body.position;
        m_audio.update(dt, { head.x, head.y + 1.5f, head.z, m_scene.camera.yaw() }, m_scene.radioStation); // el oyente es el jugador, mirando donde la cámara
        logLayer();
        return pause;
    }

    void render(ID3D11DeviceContext* context, int screenW, int screenH) {
        CRASH_SCOPE();
        CrashUtil::stage("juego: dibujar");
        m_renderer.render(context, m_scene, screenW, screenH);
        CrashUtil::stage("juego: dibujado");
    }

    // Lo que necesita la pantalla de inventario (el equipo se modifica desde ella).
    const GameData& data() const { return m_data; }
    Inventory& inventory() { return m_scene.inventory; }
    PokemonStorage& storage() { return m_scene.storage; }
    const PlayerProgress& progress() const { return m_scene.progress; }
    PlayerProgress& progress() { return m_scene.progress; }

    bool needsStarter() const { return m_scene.needsStarter(); }
    void chooseStarter(int speciesId) { m_scene.chooseStarter(speciesId); }

    // true una sola vez cuando el jugador acaba de hablar con el Profesor Oak sin tener pokémon.
    bool takeStarterRequest() {
        const bool requested = m_scene.starterRequested;
        m_scene.starterRequested = false;
        return requested;
    }

    // true una sola vez cuando el jugador acaba de usar la máquina de investigación.
    bool takeResearchRequest() {
        const bool requested = m_scene.researchRequested;
        m_scene.researchRequested = false;
        return requested;
    }

    // true una sola vez cuando el jugador interactúa con una parcela teniendo varias semillas.
    bool takeSeedRequest() {
        const bool requested = m_scene.seedRequested;
        m_scene.seedRequested = false;
        return requested;
    }
    std::vector<Scene::SeedChoice> seedChoices() const { return m_scene.seedChoices(); }
    void plantSeed(int crop) { m_scene.plantSeed(crop); }

    // Combate por turnos y aprendizaje de movimientos (la interfaz abre su pantalla y la partida queda congelada).
    bool takeBattleRequest() { const bool requested = m_scene.battleRequested; m_scene.battleRequested = false; return requested; }
    void battleOrbit(float yaw, float tilt) { m_scene.battleOrbit(yaw, tilt); }
    bool battleFirstOnLeft() const { return m_scene.battleFirstOnLeft(); }
    bool takeShopRequest() { const bool requested = m_scene.shopRequested; m_scene.shopRequested = false; return requested; }
    std::vector<const Item*> shopStock() const { return m_scene.shopStock(); }
    std::string shopBuy(int itemId, int quantity) { return m_scene.shopBuy(itemId, quantity); }
    bool takeLearnRequest() { const bool requested = m_scene.learnRequested; m_scene.learnRequested = false; return requested; }
    std::shared_ptr<Battle> battle() const { return m_scene.battle; }
    void battleAdvance(float dt) { m_scene.advanceBattleFx(dt); }
    void battlePlayFx(const Battle::Message& message) { m_scene.playBattleFx(message); }
    void battleFinish() { m_scene.finishBattle(); }

    GameStatus status() const {
        GameStatus s = m_scene.status();
        DirectX::XMStoreFloat4x4(&s.viewProj, m_scene.getViewMatrix() * DirectX::XMLoadFloat4x4(&m_renderer.projection()));
        return s;
    }

    void cleanup() {
        m_audio.shutdown();
        m_renderer.cleanup();
    }

    private:
    // Deja en el registro cada vez que el jugador entra o sale de una cueva, una mina o el cielo (para localizar fallos en cada capa).
    void logLayer() {
        const Physics::Body& body = m_scene.player.body;
        const int layer = static_cast<int>(m_scene.habitats.layerAt(body.position.x, body.position.z, body.feet()));
        if (layer == m_layer) return;
        m_layer = layer;
        static constexpr const char* NAMES[] = { "subsuelo", "superficie", "cielo" };
        char text[160];
        std::snprintf(text, sizeof(text), "Capa %s en (%.1f, %.1f, %.1f)", NAMES[(layer >= 0 && layer < 3) ? layer : 1], body.position.x, body.position.y, body.position.z);
        Logger::logInfo("ENGINE", text);
    }

    int m_layer = -1;
    GameData m_data;
    Scene m_scene;
    Renderer3D m_renderer;
    Audio::AudioEngine m_audio;
};
