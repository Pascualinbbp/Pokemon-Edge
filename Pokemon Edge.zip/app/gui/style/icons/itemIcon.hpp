#pragma once
#include <cmath>
#include "imgui.h"
#include "../../../engine/world/entities/pokeball.hpp"
#include "../../../engine/world/style/itemStyle.hpp"
#include "../../../engine/world/style/pokemonStyle.hpp"
#include "../../../models/gameData.hpp"
#include "hudIcons.hpp"

// Iconos de objetos y pokémon dibujados con ImDrawList. Es el único sitio donde se define su aspecto en la interfaz.
namespace ItemIcon {
    namespace detail {
        inline ImU32 color(const DirectX::XMFLOAT3& tone, float alpha, float shade = 1.0f) {
            const auto channel = [&](float v) { return static_cast<int>((std::min)(v * shade, 1.0f) * 255.0f); };
            return IM_COL32(channel(tone.x), channel(tone.y), channel(tone.z), static_cast<int>(255.0f * alpha));
        }
    }

    // Pokéball: su sprite (assets/sprites/<modelo>.png) o, si falta, un dibujo con los colores de su modelo (mitad superior e inferior, banda y botón central).
    inline void ball(ImDrawList* dl, const ImVec2& c, float r, const PokeballStyle::Look& look, float alpha = 1.0f) {
        if (const ImTextureID sprite = HudIcons::sprite(look.model)) { // el sprite de su modelo 3D
            dl->AddImage(sprite, ImVec2(c.x - r * 1.1f, c.y - r * 1.1f), ImVec2(c.x + r * 1.1f, c.y + r * 1.1f), ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, static_cast<int>(255.0f * alpha)));
            return;
        }
        const int a = static_cast<int>(255.0f * alpha);
        const ImU32 dark = IM_COL32(20, 20, 25, a);
        const ImU32 band = detail::color(look.band, alpha), button = detail::color(look.button, alpha);

        dl->AddCircleFilled(c, r, detail::color(look.bottom, alpha), 28);
        dl->PathArcTo(c, r, 3.1415927f, 6.2831853f, 20);
        dl->PathFillConvex(detail::color(look.color, alpha));
        dl->AddCircle(c, r, dark, 28, 2.0f);
        dl->AddLine(ImVec2(c.x - r, c.y), ImVec2(c.x + r, c.y), band, (std::max)(2.0f, r * 0.14f));
        dl->AddCircleFilled(c, r * 0.32f, button, 16);
        dl->AddCircle(c, r * 0.32f, dark, 16, 2.0f);
    }

    // Bloque del color del material (cubo en perspectiva).
    inline void block(ImDrawList* dl, const ImVec2& c, float r, const DirectX::XMFLOAT3& tone, float alpha = 1.0f) {
        const float w = r * 0.9f, h = r * 0.52f;
        const ImVec2 top[4] = { { c.x, c.y - r * 0.9f }, { c.x + w, c.y - r * 0.9f + h }, { c.x, c.y - r * 0.9f + h * 2.0f }, { c.x - w, c.y - r * 0.9f + h } };
        const ImVec2 left[4] = { top[3], top[2], { c.x, c.y + r * 0.9f }, { c.x - w, c.y + r * 0.9f - h } };
        const ImVec2 right[4] = { top[2], top[1], { c.x + w, c.y + r * 0.9f - h }, { c.x, c.y + r * 0.9f } };
        dl->AddConvexPolyFilled(top, 4, detail::color(tone, alpha, 1.25f));
        dl->AddConvexPolyFilled(left, 4, detail::color(tone, alpha, 0.85f));
        dl->AddConvexPolyFilled(right, 4, detail::color(tone, alpha, 0.65f));
    }

    // Material: su sprite (assets/sprites/items/materiales/<nombre sin tildes>.png) o, si falta, un bloque de su color.
    inline void material(ImDrawList* dl, const ImVec2& c, float r, const Item& item, float alpha = 1.0f) {
        if (const ImTextureID sprite = HudIcons::sprite(item.asset)) {
            dl->AddImage(sprite, ImVec2(c.x - r * 1.1f, c.y - r * 1.1f), ImVec2(c.x + r * 1.1f, c.y + r * 1.1f), ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, static_cast<int>(255.0f * alpha)));
            return;
        }
        block(dl, c, r, ItemStyle::materialColor(item.refId), alpha);
    }

    // Piedra evolutiva: su sprite (assets/sprites/items/piedras_evolutivas/<id>.png) o, si falta, un bloque del color de su tipo.
    inline void stone(ImDrawList* dl, const ImVec2& c, float r, const Item& item, float alpha = 1.0f) {
        if (const ImTextureID sprite = HudIcons::sprite(item.asset)) {
            dl->AddImage(sprite, ImVec2(c.x - r * 1.1f, c.y - r * 1.1f), ImVec2(c.x + r * 1.1f, c.y + r * 1.1f), ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, static_cast<int>(255.0f * alpha)));
            return;
        }
        block(dl, c, r, StyleRegistry::lookup(StyleRegistry::typeColors(), item.typeId, { 0.60f, 0.60f, 0.63f }), alpha);
    }

    // Herramienta: su sprite del nivel (assets/sprites/items/herramientas/<id>_<nivel>.png) o, si falta, mango y cabeza (hacha o pico).
    inline void tool(ImDrawList* dl, const ImVec2& c, float r, const Item& item, int level, float alpha = 1.0f) {
        const int toolId = item.refId;
        for (const std::string& name : { item.asset + "_" + std::to_string((std::max)(level, 1)), item.asset }) {
            if (name.empty() || name == "_1") continue;
            if (const ImTextureID sprite = HudIcons::sprite(name)) {
                dl->AddImage(sprite, ImVec2(c.x - r * 1.1f, c.y - r * 1.1f), ImVec2(c.x + r * 1.1f, c.y + r * 1.1f), ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, static_cast<int>(255.0f * alpha)));
                return;
            }
        }
        const ImU32 wood = IM_COL32(140, 92, 46, static_cast<int>(255.0f * alpha));
        const ImU32 metal = IM_COL32(190, 195, 205, static_cast<int>(255.0f * alpha));
        const float t = (std::max)(2.0f, r * 0.14f);
        dl->AddLine(ImVec2(c.x - r * 0.7f, c.y + r * 0.8f), ImVec2(c.x + r * 0.5f, c.y - r * 0.7f), wood, t * 1.4f);
        if (toolId == 3) { // regadera: cuerpo, pico y gotas
            const ImU32 body = IM_COL32(90, 150, 210, static_cast<int>(255.0f * alpha));
            dl->AddRectFilled(ImVec2(c.x - r * 0.7f, c.y - r * 0.2f), ImVec2(c.x + r * 0.3f, c.y + r * 0.7f), body, r * 0.12f);
            dl->AddLine(ImVec2(c.x + r * 0.3f, c.y + r * 0.45f), ImVec2(c.x + r * 0.85f, c.y - r * 0.2f), body, t * 1.6f);
            dl->AddCircleFilled(ImVec2(c.x + r * 0.9f, c.y + r * 0.1f), r * 0.07f, body);
            dl->AddCircleFilled(ImVec2(c.x + r * 0.95f, c.y + r * 0.4f), r * 0.07f, body);
        } else if (toolId == 1) { // hacha
            const ImVec2 head[4] = { { c.x + r * 0.1f, c.y - r * 0.95f }, { c.x + r * 0.85f, c.y - r * 0.55f }, { c.x + r * 0.7f, c.y + r * 0.05f }, { c.x + r * 0.15f, c.y - r * 0.35f } };
            dl->AddConvexPolyFilled(head, 4, metal);
        } else {           // pico
            dl->PathArcTo(ImVec2(c.x + r * 0.5f, c.y - r * 0.2f), r * 0.85f, 3.9f, 5.5f, 12);
            dl->PathStroke(metal, 0, t * 1.8f);
        }
    }

    // Objeto de entrenamiento: sprite de su modelo (pociones y revivir) o, sin él, un dibujo del efecto (caramelo de nivel, vitamina).
    inline void training(ImDrawList* dl, const ImVec2& c, float r, const TrainingItem& type, float alpha = 1.0f) {
        const int a = static_cast<int>(255.0f * alpha);
        const TrainingItem::Effect effect = type.effect;
        const int amount = type.amount;
        if (!type.asset.empty()) {
            if (const ImTextureID sprite = HudIcons::sprite(type.asset)) {
                dl->AddImage(sprite, ImVec2(c.x - r * 1.1f, c.y - r * 1.1f), ImVec2(c.x + r * 1.1f, c.y + r * 1.1f), ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, a));
                return;
            }
        }
        if (effect == TrainingItem::Effect::HEAL || effect == TrainingItem::Effect::REVIVE) { // frasco de poción (revivir: cristal con una chispa dorada)
            const bool revive = effect == TrainingItem::Effect::REVIVE;
            const ImU32 liquid = revive ? IM_COL32(255, 215, 80, a) : amount <= 20 ? IM_COL32(200, 110, 230, a) : amount <= 60 ? IM_COL32(240, 110, 120, a) : amount <= 120 ? IM_COL32(250, 170, 60, a) : IM_COL32(80, 200, 140, a);
            dl->AddRectFilled(ImVec2(c.x - r * 0.28f, c.y - r * 0.95f), ImVec2(c.x + r * 0.28f, c.y - r * 0.4f), IM_COL32(220, 225, 235, a), r * 0.1f);   // cuello
            dl->AddRectFilled(ImVec2(c.x - r * 0.36f, c.y - r * 1.0f), ImVec2(c.x + r * 0.36f, c.y - r * 0.8f), IM_COL32(150, 110, 70, a), r * 0.08f);    // tapón
            dl->AddCircleFilled(ImVec2(c.x, c.y + r * 0.25f), r * 0.7f, IM_COL32(230, 235, 245, a), 24);                                                  // cuerpo de vidrio
            dl->AddCircleFilled(ImVec2(c.x, c.y + r * 0.3f), r * 0.55f, liquid, 24);
            dl->AddCircle(ImVec2(c.x, c.y + r * 0.25f), r * 0.7f, IM_COL32(20, 20, 25, a), 24, 2.0f);
            if (revive) dl->AddTriangleFilled(ImVec2(c.x, c.y - r * 0.05f), ImVec2(c.x - r * 0.25f, c.y + r * 0.45f), ImVec2(c.x + r * 0.25f, c.y + r * 0.45f), IM_COL32(255, 255, 255, a));
            return;
        }
        if (effect == TrainingItem::Effect::IV_CAP || effect == TrainingItem::Effect::IV_MAX) { // chapa: disco acanalado (plateada: un tope; dorada: todos) con una estrella
            const bool gold = effect == TrainingItem::Effect::IV_MAX;
            const ImU32 rim = gold ? IM_COL32(190, 140, 20, a) : IM_COL32(120, 130, 150, a), face = gold ? IM_COL32(255, 205, 60, a) : IM_COL32(205, 214, 228, a), shine = gold ? IM_COL32(255, 240, 160, a) : IM_COL32(245, 248, 255, a);
            dl->AddCircleFilled(c, r * 0.95f, rim, 28);
            for (int i = 0; i < 16; ++i) { const float t = static_cast<float>(i) / 16.0f * 6.2831853f; dl->AddCircleFilled(ImVec2(c.x + std::cos(t) * r * 0.9f, c.y + std::sin(t) * r * 0.9f), r * 0.09f, face, 8); }
            dl->AddCircleFilled(c, r * 0.78f, face, 28);
            dl->AddCircle(c, r * 0.78f, rim, 28, 1.5f);
            ImVec2 star[10];
            for (int i = 0; i < 10; ++i) { const float t = -1.5707963f + static_cast<float>(i) * 0.6283185f, k = i % 2 == 0 ? r * 0.5f : r * 0.22f; star[i] = ImVec2(c.x + std::cos(t) * k, c.y + std::sin(t) * k); }
            dl->AddConvexPolyFilled(star, 10, rim);
            dl->AddCircleFilled(ImVec2(c.x - r * 0.35f, c.y - r * 0.4f), r * 0.12f, shine, 10);
            return;
        }
        if (effect == TrainingItem::Effect::LEVEL) {
            const ImU32 wrap = IM_COL32(120, 200, 255, a);
            dl->AddTriangleFilled(ImVec2(c.x - r * 0.55f, c.y), ImVec2(c.x - r * 1.0f, c.y - r * 0.4f), ImVec2(c.x - r * 1.0f, c.y + r * 0.4f), wrap);
            dl->AddTriangleFilled(ImVec2(c.x + r * 0.55f, c.y), ImVec2(c.x + r * 1.0f, c.y - r * 0.4f), ImVec2(c.x + r * 1.0f, c.y + r * 0.4f), wrap);
            dl->AddCircleFilled(c, r * 0.62f, IM_COL32(90, 160, 240, a), 24);
            dl->AddCircle(c, r * 0.62f, IM_COL32(230, 245, 255, a), 24, 2.0f);
            dl->AddLine(ImVec2(c.x - r * 0.3f, c.y - r * 0.15f), ImVec2(c.x + r * 0.3f, c.y - r * 0.15f), IM_COL32(255, 255, 255, a), 2.0f);
        } else {
            dl->AddRectFilled(ImVec2(c.x - r * 0.35f, c.y - r * 0.9f), ImVec2(c.x + r * 0.35f, c.y + r * 0.9f), IM_COL32(235, 235, 240, a), r * 0.35f);
            dl->AddRectFilled(ImVec2(c.x - r * 0.35f, c.y), ImVec2(c.x + r * 0.35f, c.y + r * 0.9f), IM_COL32(230, 70, 80, a), r * 0.35f, ImDrawFlags_RoundCornersBottom);
            dl->AddRect(ImVec2(c.x - r * 0.35f, c.y - r * 0.9f), ImVec2(c.x + r * 0.35f, c.y + r * 0.9f), IM_COL32(20, 20, 25, a), r * 0.35f, 0, 2.0f);
        }
    }

    // Pokémon: cubo del color de su especie con morro (igual que en el mundo).
    inline void creature(ImDrawList* dl, const ImVec2& c, float r, int speciesId, float alpha = 1.0f, float darken = 0.0f, bool gray = false) { // gray: debilitado, en tonos grises
        const DirectX::XMFLOAT3 tone = PokemonStyle::color(speciesId);
        const float keep = 1.0f - darken; // darken = 1 -> silueta casi negra (pokémon sin ver)
        const float luma = 0.3f * tone.x + 0.59f * tone.y + 0.11f * tone.z;
        const DirectX::XMFLOAT3 shaded = gray ? DirectX::XMFLOAT3{ luma * keep, luma * keep, luma * keep } : DirectX::XMFLOAT3{ tone.x * keep, tone.y * keep, tone.z * keep };
        const auto fade = [&](int r8, int g8, int b8) { if (gray) r8 = g8 = b8 = (r8 * 3 + g8 * 6 + b8) / 10; return IM_COL32(static_cast<int>(r8 * keep), static_cast<int>(g8 * keep), static_cast<int>(b8 * keep), static_cast<int>(255.0f * alpha)); };
        dl->AddRectFilled(ImVec2(c.x - r * 0.8f, c.y - r * 0.8f), ImVec2(c.x + r * 0.8f, c.y + r * 0.8f), detail::color(shaded, alpha), r * 0.15f);
        dl->AddRectFilled(ImVec2(c.x + r * 0.35f, c.y - r * 0.1f), ImVec2(c.x + r * 0.95f, c.y + r * 0.35f), fade(255, 230, 40), r * 0.08f);
        dl->AddCircleFilled(ImVec2(c.x - r * 0.2f, c.y - r * 0.25f), r * 0.1f, IM_COL32(20, 20, 25, static_cast<int>(255.0f * alpha)));
    }

    // Icono de cualquier objeto del inventario, según su categoría.
    // Objeto equipable: medallón del color de su efecto con un símbolo en blanco (reparto, garra, cinta, baya, esfera).
    inline void held(ImDrawList* dl, const ImVec2& c, float r, const HeldItem& type, float alpha = 1.0f) {
        const int a = static_cast<int>(255.0f * alpha);
        const int rgb = type.rgb >= 0 ? type.rgb : 0x8C8CA0;
        const ImU32 base = IM_COL32((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, a), dark = IM_COL32(0, 0, 0, static_cast<int>(90.0f * alpha)), white = IM_COL32(255, 255, 255, a);
        dl->AddCircleFilled(c, r, base, 28);
        dl->AddCircle(c, r, dark, 28, r * 0.12f);
        const float t = (std::max)(1.5f, r * 0.12f);
        switch (type.effect) {
            case HeldItem::Effect::EXP_SHARE:
                dl->AddCircle(ImVec2(c.x - r * 0.22f, c.y), r * 0.38f, white, 20, t);
                dl->AddCircle(ImVec2(c.x + r * 0.22f, c.y), r * 0.38f, white, 20, t);
                break;
            case HeldItem::Effect::QUICK_CLAW:
            case HeldItem::Effect::RAZOR_CLAW:
                for (int i = -1; i <= 1; ++i) dl->AddLine(ImVec2(c.x + i * r * 0.32f - r * 0.12f, c.y - r * 0.5f), ImVec2(c.x + i * r * 0.32f + r * 0.12f, c.y + r * 0.5f), white, type.effect == HeldItem::Effect::RAZOR_CLAW ? t * 1.4f : t);
                break;
            case HeldItem::Effect::FOCUS_BAND:
                dl->AddLine(ImVec2(c.x - r * 0.55f, c.y), ImVec2(c.x + r * 0.55f, c.y), white, t * 2.2f);
                dl->AddLine(ImVec2(c.x - r * 0.55f, c.y - r * 0.28f), ImVec2(c.x + r * 0.55f, c.y - r * 0.28f), white, t * 0.8f);
                break;
            case HeldItem::Effect::LEFTOVERS:
                dl->AddCircleFilled(ImVec2(c.x, c.y + r * 0.1f), r * 0.38f, white, 18);
                dl->AddLine(ImVec2(c.x, c.y - r * 0.3f), ImVec2(c.x + r * 0.2f, c.y - r * 0.6f), white, t);
                break;
            case HeldItem::Effect::LIFE_ORB:
                dl->AddCircleFilled(c, r * 0.45f, white, 20);
                dl->AddCircleFilled(ImVec2(c.x - r * 0.15f, c.y - r * 0.15f), r * 0.15f, base, 12);
                break;
        }
    }

    // 'count': unidades que se tienen; en las herramientas es su nivel (elige el sprite).
    inline void item(ImDrawList* dl, const ImVec2& c, float r, const Item& item, const GameData& data, float alpha = 1.0f, int count = 1) {
        switch (item.category) {
            case ItemCategory::HELD:     if (const HeldItem* type = data.held(item.refId)) held(dl, c, r, *type, alpha); break;
            case ItemCategory::POKEBALL: if (const PokeballType* type = data.ball(item.refId)) ball(dl, c, r, PokeballStyle::look(type->id), alpha); break;
            case ItemCategory::MATERIAL: material(dl, c, r, item, alpha); break;
            case ItemCategory::STONE:    stone(dl, c, r, item, alpha); break;
            case ItemCategory::TOOL:     tool(dl, c, r, item, count, alpha); break;
            case ItemCategory::TRAINING: if (const TrainingItem* type = data.training(item.refId)) training(dl, c, r, *type, alpha); break;
            default: break;
        }
    }

    // Color de fondo de las casillas de cada categoría de objeto.
    inline ImU32 categoryTone(ItemCategory category) {
        switch (category) {
            case ItemCategory::POKEBALL: return IM_COL32(52, 96, 190, 255);
            case ItemCategory::MATERIAL: return IM_COL32(196, 128, 48, 255);
            case ItemCategory::STONE:    return IM_COL32(190, 70, 110, 255);
            case ItemCategory::TOOL:     return IM_COL32(120, 76, 190, 255);
            case ItemCategory::TRAINING: return IM_COL32(40, 150, 120, 255);
            case ItemCategory::HELD:     return IM_COL32(200, 150, 40, 255);
            default:                     return IM_COL32(90, 90, 100, 255);
        }
    }
}
