#pragma once
#include <array>
#include <map>
#include <string>
#include <vector>

// Datos persistidos de una partida. Se irá ampliando a medida que avance el juego.
// Un pokémon del equipo tal como se enseña en la lista de partidas.
struct SaveTeamMember {
    int speciesId = 0;
    int level = 1;
    bool shiny = false;
};

// Datos que enseña la lista de partidas guardadas (se guardan aparte para no tener que cargar la partida entera).
struct SaveSummary {
    std::vector<SaveTeamMember> team;
    int playerLevel = 1;
    int badges = 0;
    int money = 0;
    int dexCaught = 0;
};

struct SaveData {
    SaveSummary summary;
    std::array<float, 3> playerPosition = { 0.0f, 0.0f, 0.0f };
    unsigned worldSeed = 0;  // semilla del mapa de hábitats; 0 = sin dato (partidas antiguas: se genera uno nuevo)
    float worldTime = -1.0f; // segundos dentro del ciclo día/noche; negativo = sin dato (se usa el inicio por defecto)
    std::map<std::string, int> items; // unidades de cada objeto por nombre; vacío = valores iniciales
    std::string selectedBall;         // pokéball equipada; vacío = la primera
    int money = 0;                    // pokémonedas
    std::vector<std::string> team;    // especies del equipo (el primero es el líder)
    std::vector<std::string> pc;      // pokémon guardados en el PC
    int playerLevel = 1;              // nivel, experiencia y medallas del jugador
    int playerXp = 0;
    int badges = 0;
    unsigned badgeMask = 0;           // qué medallas se tienen (bit = id de la medalla)
    int activeIndex = 0;              // pokémon del equipo que acompaña al jugador
    std::string explored;             // zonas exploradas del mundo (Exploration::store); vacío = nada explorado
    std::vector<std::string> dexSeen;   // Pokédex: especies vistas y capturadas (por nombre)
    std::vector<std::string> dexCaught;
    std::vector<std::string> dexProgress; // logros por especie y recompensas reclamadas (DexProgress::store)
    int autoReleaseRank = 0;          // potencial mínimo que conserva la máquina de investigación (índice de IvRules::RANKS)
};

// Resumen de una ranura de partida para mostrarla en los menús.
struct SaveSlotInfo {
    bool used = false;
    std::string savedAtText; // fecha y hora ya formateadas (se calculan al guardar, no en cada frame)
    SaveSummary summary;     // equipo, nivel, medallas...: vacío en partidas guardadas antes de existir el resumen
    bool hasSummary = false;
};
